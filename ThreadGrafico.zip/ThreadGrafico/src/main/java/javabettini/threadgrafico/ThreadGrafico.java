package javabettini.threadgrafico;

import java.util.concurrent.Semaphore;

public class ThreadGrafico {

    public static void main(String[] args) {
        Frame f = new Frame();
    }
}